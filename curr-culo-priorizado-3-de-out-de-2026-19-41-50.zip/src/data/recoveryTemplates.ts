import { OFFICIAL_RECOVERY_DATA_2026 } from "./recoveryData2026";
import { LOGO_SP_BASE64 } from "./logoSp";

export interface RecoveryPlanResult {
  title: string;
  ancoragemLegal: string;
  verboComando?: string;
  objetoConhecimento?: string;
  revisaoAulas?: string;
  diagnosticoDificuldades?: string;
  intervencaoPedagogica?: string;
  metodologiasDiferenciadas?: string;
  instrumentosAvaliacao?: string;
  matrizCognitiva: string;
  planoAulas: string;
  exercicioQuestoes?: Array<{
    enunciado: string;
    gabarito: string;
    justificativa: string;
  }>;
  orientacoesAcompanhamento?: string;
  modificador?: string;
  habilidadesRelacionadas?: string;
  habilidadesPrevias?: string;
  itemAvaliacao?: string;
  gabarito?: string;
  feedbackPedagogico?: string;
  fullMarkdown?: string;
}

function escapeHtml(a: any): string {
  return a == null ? "" : String(a).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function normalizeStr(a: string): string {
  return a.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
}

export const PRESET_RECOVERY_TEMPLATES: Record<string, RecoveryPlanResult> = {tecnologia_7:{title:"Plano de Recuperação e Aprofundamento Semestral (Currículo Paulista 2026)",ancoragemLegal:"Conforme Resolução SEDUC 42/2024, para estudantes com rendimento abaixo de 5,0 no 1º semestre (1º e 2º Bimestres). Registro de acompanhamento na SED e 'Professor Presente', focando na recomposição de habilidades essenciais e no preparo para a Prova Paulista.",verboComando:"Identificar, descrever e desenvolver (Nível de Bloom: Compreensão / Aplicação)",objetoConhecimento:"1º Bimestre: Arquivos compactados (.zip, .rar) | 2º Bimestre: Algoritmos simples, raciocínio lógico e programação em blocos.",modificador:"Para compreender a compactação de dados e desenvolver o pensamento computacional por meio de lógica de programação aplicada ao cotidiano.",habilidadesRelacionadas:`1º Bimestre: EF07TE02 - Identificar o funcionamento de arquivos compactados e descrever vantagens da compressão de dados.
2º Bimestre: EF07TE04 - Desenvolver algoritmos de programação simples para solucionar situações cotidianas.`,habilidadesPrevias:"Noções básicas de pastas e diretórios digitais e ordenação lógica de passos.",matrizCognitiva:`| Grupo Cognitivo | 1º Bimestre - Foco (Arquivos) | 2º Bimestre - Foco (Lógica) |
| :--- | :--- | :--- |
| **Grupo 1: Identificar** | Identificar arquivos compactados (.zip) e a redução de espaço em disco. | Reconhecer algoritmo como uma sequência finita de instruções ordenadas. |
| **Grupo 2: Aplicar** | Comparar o tamanho de pastas normais com suas versões compactadas. | Usar blocos de programação visual para criar instruções condicionais (se/então). |
| **Grupo 3: Analisar** | Resolver limites de anexo aplicando compactação de arquivos escolares. | Analisar fluxogramas lógicos, identificar erros e corrigir algoritmos. |`,planoAulas:`| Aula | Período / Bimestre | Conteúdo | Metodologia Ativa e Prática de Sala de Aula | Recursos Pedagógicos |
| :--- | :--- | :--- | :--- | :--- |
| **1** | 1º Bimestre | Arquivos Compactados (.zip, .rar) | **Roda de Conversa e Duplas**: Comparação com malas de viagem. Trabalho em duplas com auxílio de estudante monitor. | Material Digital SEDUC-SP, computadores. |
| **2** | 1º Bimestre | Algoritmos e Redução de Bytes | **Estudo Dirigido**: Prática de compactação de pastas com imagens e registro da economia de espaço. | Plataforma Start (Alura), Material Digital. |
| **3** | 1º Bimestre | Transmissão de Dados e Anexos | **Resolução de Problemas**: Desafio de envio de portfólio com limite de tamanho no e-mail. | Material Digital SEDUC-SP, e-mail escolar. |
| **4** | 1º Bimestre | Organização e Revisão | **Rotação por Estações**: Estação 1: Exercício; Estação 2: Desafio teórico; Estação 3: Autoavaliação. | Fichas de exercícios, folha de registro. |
| **5** | 2º Bimestre | Lógica e Algoritmos | **Programação Desplugada**: Elaboração de comandos em papel para guiar um colega em um circuito. | Quadro, fita adesiva, papel. |
| **6** | 2º Bimestre | Programação de Blocos Visuais | **Oficina Prática**: Enigmas de programação em blocos com apoio do professor tutor aos grupos em defasagem. | Plataforma de blocos visuais, computadores. |
| **7** | 2º Bimestre | Decisão Condicional (Se / Senão) | **Estudo de Caso**: Programação de comandos para automação simples (ex: luz de segurança). | Computadores, Material Digital SEDUC-SP. |
| **8** | 2º Bimestre | Consolidação Semestral | **Apresentação de Projetos**: Exposição de algoritmos e autoavaliação dos estudantes. | Rubricas de autoavaliação, Material Digital. |`,itemAvaliacao:`**Questão 1 (1º Bimestre - Compressão de Arquivos)**
**Enunciado:** Durante uma aula no Laboratório de Tecnologia, um grupo de alunos do 7º ano precisa enviar o projeto semestral contendo fotos e relatórios de texto para o e-mail do professor. Contudo, ao tentar anexar os arquivos individualmente, o sistema exibe uma mensagem de erro informando que o limite de 25 MB do anexo foi excedido, pois a soma total dos arquivos originais é de 48 MB.
Considerando os conceitos de armazenamento e transmissão de dados do Currículo Paulista, qual ação técnica soluciona esse problema para que enviem todos os arquivos de uma vez com segurança?
A) Copiar e colar todos os textos brutos de uma única vez no corpo do e-mail para burlar as medições de tamanho em MB de anexo.
B) Reunir todos os arquivos originais em uma única pasta digital do sistema operacional e utilizar a ferramenta padrão para compactá-la no formato ZIP.
C) Excluir metade das fotos do projeto para reduzir à força o tamanho total, comprometendo o escopo pedagógico da entrega.
D) Alterar de forma literal o nome das extensões de todas as imagens de .jpg para .zip sem aplicar nenhum software de compressão.

**Questão 2 (2º Bimestre - Lógica de Programação)**
**Enunciado:** No desenvolvimento de um algoritmo em blocos visuais de programação, um aluno deseja criar um sistema simples de segurança escolar que decide se uma lâmpada externa deve acender ou apagar. A regra lógica é: se o sensor de luminosidade detectar que está escuro, a lâmpada acende; caso contrário (se estiver claro), a lâmpada apaga.
Para estruturar essa sequência lógica perfeitamente de acordo com os conceitos de algoritmos estudados em Tecnologia e Inovação, qual estrutura condicional deve ser empregada?
A) Uma instrução de loop repetitivo infinito (como "Repita 10 vezes") sem testar nenhuma variável de luminosidade.
B) Uma estrutura de tomada de decisão condicional do tipo "Se (Sensor detecta escuro) Então (Lâmpada acende) Senão (Lâmpada apaga)".
C) Um comando de desligamento geral do computador para que a lâmpada seja controlada de forma puramente manual por um interruptor externo.
D) Uma linha única de atribuição de variável de texto indefinido que não executa testes lógicos sobre as condições do sensor.`,gabarito:"Questão 1: B | Questão 2: B",feedbackPedagogico:`- **Questão 1 - Justificativa da Alternativa Correta (B)**: A compactação reúne múltiplos elementos digitais em um só recipiente reduzindo o seu tamanho total em bytes (compressão de dados) sem perder nenhuma informação, permitindo que a pasta fique abaixo do limite de anexo e seja enviada perfeitamente (habilidade EF07TE02).
- **Questão 2 - Justificativa da Alternativa Correta (B)**: A estrutura condicional "Se/Então/Senão" é o mecanismo computacional adequado para a tomada de decisão em fluxogramas e códigos de bloco, bifurcando o fluxo de execução baseado na veracidade da condição testada (habilidade EF07TE04).
- **Análise dos Distratores (Questão 1)**: A alternativa A não reduz bytes reais e causará erro de tamanho de corpo; a alternativa C destrói conteúdo didático desnecessariamente; a alternativa D apenas corrompe as imagens porque mudar o nome da extensão não comprime seus dados internos.
- **Análise dos Distratores (Questão 2)**: A alternativa A gerará um loop sem sentido sem tomada de decisão; as alternativas C e D anulam a automação inteligente pretendida pelo algoritmo, descaracterizando o pensamento computacional.`,fullMarkdown:""}};

function generateExerciseQuestion(a,e,i){let o=`No âmbito das competências gerais do Currículo Paulista, para resolver problemas sobre **${e}** (${i}), qual procedimento metodológico o estudante deve adotar de acordo com as diretrizes educacionais?`,s=`Identificar os elementos conceituais fundamentais de **${e}**, aplicar de maneira estruturada as relações lógicas e analisar criticamente as soluções geradas com suporte nos recursos pedagógicos do Material Digital.`,t=`A compreensão sistemática dos termos básicos de ${e} aliada à lógica reflexiva atende plenamente aos níveis de proficiência cognitiva esperados na Prova Paulista de recomposição escolar.`;return a.includes("matematica")||a.includes("financeira")||a.includes("orientacao de estudos")?(o=`Ao resolver uma situação-problema de matemática que mobiliza conhecimentos sobre **${e}** (${i}), qual é o procedimento técnico estruturado pelo Currículo Paulista para garantir precisão e fundamentação lógica?`,s="Identificar as variáveis numéricas, modelar a situação matematicamente através de expressões ou equações reais e verificar a consistência física ou lógica dos resultados obtidos.",t="A habilidade de modelar situações reais por meio do raciocínio analítico matemático constitui a meta central das intervenções pedagógicas de Matemática no Currículo Paulista."):a.includes("portugues")||a.includes("lingua portuguesa")||a.includes("redacao")||a.includes("leitura")?(o=`Ao analisar e interpretar textos literários, acadêmicos ou jornalísticos associados a **${e}** (${i}), qual estratégia de leitura crítica favorece o desenvolvimento da proficiência leitora do estudante?`,s="Localizar dados explícitos e implícitos no texto, reconhecer os elementos composicionais típicos do gênero discursivo e correlacionar as escolhas de linguagem com as intenções comunicativas do autor.",t="A leitura analítica fundamentada no reconhecimento de gêneros textuais e na articulação de ideias é essencial para a recomposição pedagógica em Língua Portuguesa."):a.includes("fisica")||a.includes("quimica")||a.includes("biologia")||a.includes("ciencias")?(o=`Para analisar e resolver problemas científicos que abordam fenômenos biológicos ou físicos associados a **${e}** (${i}), qual postura investigativa é preconizada pelo Currículo Paulista?`,s="Observar as variáveis físicas ou biológicas envolvidas, elaborar hipóteses plausíveis com suporte em teorias científicas validadas e interpretar os dados experimentais coletados.",t=`O letramento científico preconiza que o discente saiba interpretar fenômenos de ${e} correlacionando variáveis, causas e consequências reais de forma ordenada.`):a.includes("historia")||a.includes("geografia")||a.includes("filosofia")||a.includes("sociologia")?(o=`Ao analisar processos de transformação histórica, social, espacial ou estética relacionados a **${e}** (${i}), qual abordagem crítica e analítica as Ciências Humanas recomendam priorizar?`,s="Examinar diferentes fontes documentais ou cartográficas, contextualizar os fatos em seus múltiplos marcos temporais/espaciais e identificar relações de causalidade, hegemonia ou poder.",t="As Ciências Humanas exigem a desconstrução crítica de discursos dogmáticos para que o educando compreenda as estruturas de tempo e espaço de forma reflexiva e consciente."):(a.includes("ingles")||a.includes("inglesa"))&&(o=`To develop reading comprehension and communicative skills in English regarding **${e}** (${i}), what is the primary active strategy recommended?`,s="Apply reading strategies such as skimming and scanning to locate explicit details, make contextual inferences, and recognize structural grammar patterns in English texts.",t="Using active reading processes and utilizing contextual clues is essential to build linguistic independence and critical comprehension of texts in English."),{itemText:`**Questão (${i})**
**Enunciado:** ${o}

A) Utilizar apenas o senso comum e palpites aleatórios, dispensando teorias, fórmulas, dados oficiais ou leituras críticas do Material Digital.
B) ${s}
C) Chutar mecanicamente as alternativas de resposta sem efetuar a devida interpretação de textos, gráficos ou dados de apoio fornecidos.
D) Tratar o conteúdo como sabedoria abstrata e sem utilidade prática para o cotidiano, omitindo-se da realização das atividades escolares recomendadas.`,questionHeader:o,optionBCorrect:s,feedbackCorrect:t}}

function renderMarkdownTableToHtml(a){const e=a.trim().split(`
`).map(d=>d.trim()).filter(d=>d.startsWith("|"));if(e.length<2)return a;const i=e[0].split("|").slice(1,-1).map(d=>d.trim()),o=i.length||1,s=(100/o).toFixed(2)+"%";let t='<table border="1" width="100%" style="width: 100%; border-collapse: collapse; margin-top: 10px; margin-bottom: 15px; border: 1.5px solid #1e3a8a; font-size: 9.5pt; line-height: 1.45; font-family: Arial, Helvetica, sans-serif; table-layout: fixed; mso-table-layout-alt: fixed; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">';t+="<colgroup>";for(let d=0;d<o;d++)t+=`<col width="${s}" style="width: ${s};">`;t+="</colgroup>",t+="<thead><tr style='background-color: #1e3a8a; color: white;'>",i.forEach(d=>{t+=`<th width="${s}" style='border: 1px solid #1e3a8a; padding: 10px 12px; text-align: left; font-weight: bold; width: ${s}; word-wrap: break-word; overflow-wrap: break-word;'>${d}</th>`}),t+="</tr></thead><tbody>";for(let d=2;d<e.length;d++){const c=e[d].split("|").slice(1,-1).map(p=>p.trim()),m=d%2===0?"#f8fafc":"#ffffff";t+=`<tr style='background-color: ${m};'>`,c.forEach(p=>{let b=p.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>");t+=`<td width="${s}" style='border: 1px solid #cbd5e1; padding: 8px 12px; vertical-align: top; color: #334155; width: ${s}; word-wrap: break-word; overflow-wrap: break-word;'>${b}</td>`}),t+="</tr>"}return t+="</tbody></table>",t}

export function matchOfficialRecoveryItem(a,e,i){const o=normalizeStr(a),s=normalizeStr(e),t=normalizeStr(i),d=Object.keys(OFFICIAL_RECOVERY_DATA_2026).find(v=>{const A=normalizeStr(v);return A.includes(o)||o.includes(A)});if(!d)return null;const c=OFFICIAL_RECOVERY_DATA_2026[d],m=Object.keys(c).find(v=>{const A=normalizeStr(v);return A.includes(s)||s.includes(A)});if(!m)return null;const p=c[m];let b=Object.keys(p).find(v=>{const A=normalizeStr(v);return A.includes(t)||t.includes(A)});if(b||(b=Object.keys(p)[0]),!b)return null;const f=p[b];return f&&f.length>0?f[0]:null}

export function generateCustomRecoveryPlan(a){const e=normalizeStr(a.componente),i=normalizeStr(a.ano),o=Object.keys(OFFICIAL_RECOVERY_DATA_2026).find(H=>{const W=normalizeStr(H);return W.includes(e)||e.includes(W)});let s=null,t=null;if(o){const H=OFFICIAL_RECOVERY_DATA_2026[o],W=Object.keys(H).find(de=>{const le=normalizeStr(de);return le.includes(i)||i.includes(le)});if(W){const de=H[W],le=Object.keys(de).find(je=>normalizeStr(je).includes("1"));le&&de[le]&&de[le].length>0&&(s=de[le][0]);const ue=Object.keys(de).find(je=>normalizeStr(je).includes("2"));ue&&de[ue]&&de[ue].length>0&&(t=de[ue][0])}}const d=a.componente.toLowerCase(),c=H=>H.replace(/atividade\s+verificadora(\s+de\s+aprendizagem)?/gi,"").replace(/Atividade\s+Verificadora(\s+de\s+Aprendizagem)?/gi,"").replace(/:\s*$/,"").trim(),m=(H,W)=>{const de=c(W).split(/[,;|•\n]+/).map(le=>le.trim()).filter(Boolean);return de.length>0?`${H}:
`+de.map(le=>`  • ${le}`).join(`
`):""},p=(H,W)=>{const de=W.split(/[\n;]+/).map(le=>le.trim()).filter(Boolean);return de.length>0?`${H}:
`+de.map(le=>`  • ${le}`).join(`
`):""};let b="";if(s&&t)b=m("1º Bimestre",s.conteudo)+`
`+m("2º Bimestre",t.conteudo);else if(s)b=m("1º Bimestre",s.conteudo);else if(t)b=m("2º Bimestre",t.conteudo);else{const H=a.aprendizagemEssencial.split(/\n/);H.length>1?b=m("1º Bimestre",H[0])+`
`+m("2º Bimestre",H[1]):b=m("1º e 2º Bimestres",a.aprendizagemEssencial)}let f="";if(s&&t)f=p("1º Bimestre",s.habilidade)+`
`+p("2º Bimestre",t.habilidade);else if(s)f=p("1º Bimestre",s.habilidade);else if(t)f=p("2º Bimestre",t.habilidade);else{const H=a.descritores.split(/\n/);H.length>1?f=p("1º Bimestre",H[0])+`
`+p("2º Bimestre",H[1]):f=p("1º e 2º Bimestres",a.descritores)}let v="Diferenciar, aplicar e resolver (Nível de Bloom: Análise / Aplicação)";if(s||t){let H="Identificar",W="Analisar";if(s){const de=s.habilidade.replace(/^([A-Z0-9-]+\s*[-—]?\s*)/,"").trim().split(" ");de.length>0&&(H=de[0].replace(/[,;.:]/g,""))}if(t){const de=t.habilidade.replace(/^([A-Z0-9-]+\s*[-—]?\s*)/,"").trim().split(" ");de.length>0&&(W=de[0].replace(/[,;.:]/g,""))}v=`${H} (1º Bimestre) e ${W} (2º Bimestre) – Alinhado ao Currículo Paulista`}const A=s?s.conteudo:b.split("|")[0]||b,E=t?t.conteudo:b.split("|")[1]||b,C="Para aplicar, compreender, comparar e resolver situações-problema associadas aos eixos estruturantes do 1º Semestre de 2026, com foco na superação de lacunas aferidas pela Prova Paulista.",S=`Habilidades de suporte dos anos escolares anteriores relacionadas aos conteúdos essenciais de ${A} (1º Bimestre) e ${E} (2º Bimestre). Ativação prática: realização de quizzes interativos rápidos, retomada de tabelas analógicas de dados e contextualizações do cotidiano no início de cada semana de estudo.`,T=`| Grupo Cognitivo | 1º Bimestre - Foco de Intervenção | 2º Bimestre - Foco de Intervenção |
| :--- | :--- | :--- |
| **Grupo 1: Reconhecer / Identificar** | Reconhecer termos teóricos, definições elementares e vocabulários técnicos associados a **${A}**. | Identificar as características básicas, representações gráficas ou esquemáticas de **${E}**. |
| **Grupo 2: Aplicar / Comparar** | Aplicar as definições estruturadas para resolver problemas de proficiência básica e fazer comparações com o cotidiano de **${A}**. | Comparar cenários de dados reais ou científicos correlacionando regras conceituais e operações práticas de **${E}**. |
| **Grupo 3: Analisar / Resolver Problemas** | Analisar dados, extrair inferências críticas profundas de textos ou fórmulas e resolver problemas novos associando **${A}**. | Elaborar modelos explicativos ou esquemas lógicos estruturados e solucionar problemas complexos padrão Prova Paulista sobre **${E}**. |`;let M=`| Aula | Período / Bimestre | Objeto de Estudo (Conteúdo) | Metodologia Ativa e Prática de Sala de Aula | Recursos Pedagógicos |
| :--- | :--- | :--- | :--- | :--- |
`;const F=a.aulas||8,R=Math.ceil(F/2),N=F-R,w=s&&s.revisaoAulas&&s.revisaoAulas.length>0?s.revisaoAulas:[A],z=t&&t.revisaoAulas&&t.revisaoAulas.length>0?t.revisaoAulas:[E];for(let H=1;H<=F;H++){const W=H<=R,de=W?"1º Bimestre":"2º Bimestre",le=W?w:z,ue=W?H-1:H-R-1,je=W?R:N,he=Math.min(Math.floor(ue/(je/le.length)),le.length-1),ze=le[he];let K=`**Ancoragem Prática**: Levantamento de ideias prévias e conexões cotidianas com o tema de **${ze}** em duplas de proficiência diversificada. O **Aluno Monitor do BEEM** fornece apoio orientador aos colegas com dificuldades.`;const D=(ue+1)/je;D>.7?K=`**Metodologia Baseada em Desafios (PBL)**: Resolução de situações complexas de **${ze}** no modelo de complexidade cognitiva da Prova Paulista, com apoio ativo e mediação individual do **Professor Tutor**.`:D>.3&&(K="**Estudo de Caso Prático**: Investigação coletiva de dados, análise de tabelas ou textos e aplicação de fórmulas e regras conceituais em grupos de cooperação para desenvolver a autonomia intelectual."),M+=`| **${H}** | ${de} | Recomposição: ${ze} | ${K} | Slides do Material Digital SEDUC-SP, Caderno do Estudante. |
`}const G=generateExerciseQuestion(d,A,"1º Bimestre"),B=generateExerciseQuestion(d,E,"2º Bimestre"),Z=`${G.itemText}

---

${B.itemText}`,Q="Questão 1: B | Questão 2: B",y=`### **Questão 1 (1º Bimestre - ${A})**
- **Justificativa da alternativa correta (B)**: ${G.feedbackCorrect}
- **Análise do distrator A**: Confiar apenas em especulação ingênua ou achismo carece do rigor científico e metodológico do Material Digital e das diretrizes curriculares do Estado.
- **Análise do distrator C**: O palpite desatento impossibilita diagnosticar com precisão a proficiência, tratando-se de uma postura inadequada diante de exames formativos importantes.
- **Análise do distrator D**: A teoria curricular fornece o suporte cognitivo e prático essencial para instrumentalizar o aluno no cotidiano pessoal e comunitário.

### **Questão 2 (2º Bimestre - ${E})**
- **Justificativa da alternativa correta (B)**: ${B.feedbackCorrect}
- **Análise do distrator A**: Resoluções irracionais e sem critérios anulam o desenvolvimento da lógica reflexiva de recomposição de defasagem de aprendizagem.
- **Análise do distrator C**: Abandonar os métodos formais em prol de palpites aleatórios compromete diretamente o desempenho no currículo paulista de 2026.
- **Análise do distrator D**: Negar a relevância pedagógica da aplicação teórica em problemas do cotidiano gera desinteresse e inércia de protagonismo estudantil.`;return{title:"Plano de Recuperação e Aprofundamento Semestral (Currículo Paulista 2026)",ancoragemLegal:"Fundamentado na Resolução SEDUC 42/2024, que rege as diretrizes e normas administrativas da recuperação semestral para os componentes da Formação Geral Básica e Itinerários Formativos, estabelecendo que estudantes com rendimento inferior a 5,0 devem passar por intervenções imediatas e contínuas registradas na Secretaria Escolar Digital (SED) e no sistema 'Professor Presente' (Resolução SEDUC 140/2025). Alinhado também ao cronograma oficial do 1º Semestre Letivo de 2026 (02/02 a 03/07), com a consolidação da Semana de Estudos Intensivos (SEI) de fechamento de período e a aplicação da Prova Paulista do semestre letivo.",verboComando:v,objetoConhecimento:b,modificador:C,habilidadesRelacionadas:f,habilidadesPrevias:S,matrizCognitiva:T,planoAulas:M,itemAvaliacao:Z,gabarito:Q,feedbackPedagogico:y,fullMarkdown:""}}

export function buildRecoveryPlanHTML(a,e,i,o){const s=renderMarkdownTableToHtml(i.matrizCognitiva),t=renderMarkdownTableToHtml(i.planoAulas),d=(o.adaptacaoCurricularOptions&&o.adaptacaoCurricularOptions.length>0?o.adaptacaoCurricularOptions:["Responder dúvidas recorrentes, retomando explicações","Oferecer exemplos adicionais ou utilizar outra estratégia de explicação para o mesmo conceito","Propor atividades de apoio para estudantes que ainda não consolidaram a aprendizagem","Disponibilizar desafios para estudantes que já dominaram o conteúdo"]).map(p=>`<li style="margin-bottom: 6px; line-height: 1.5;">${escapeHtml(p)}</li>`).join(""),c=escapeHtml(o.sugestaoMateriais||"Jogos pedagógicos, fichas de exercícios impressas com apoio visual, esquemas gráficos e infográficos, objetos manipuláveis e tutoria entre pares."),m=escapeHtml(o.retomadaAprendizagensAnteriores||"Revisão prática dos conceitos fundamentais do 1º e 2º bimestres anteriores necessários para a consolidação das habilidades essenciais em defasagem.");return`
    <div style="font-family: Cambria, 'Cambria Math', Georgia, serif; color: #1e293b; line-height: 1.5; font-size: 11pt; max-width: 100%; box-sizing: border-box;">
      <!-- CABEÇALHO OFICIAL SEDUC COM LOGO SP -->
      <table border="0" width="100%" style="width: 100%; border-collapse: collapse; margin-bottom: 16px; border: none; font-family: Cambria, Georgia, serif;">
        <tr>
          <td style="width: 150px; vertical-align: middle; border: none; padding: 0;">
            <img src="${LOGO_SP_BASE64}" alt="Logo Governo SP" style="width: 140px; height: auto; display: block;" />
          </td>
          <td style="vertical-align: middle; border: none; padding: 0; text-align: center;">
            <h4 style="margin: 0; font-family: Cambria, Georgia, serif; font-size: 9.5pt; font-weight: bold; color: #64748b; letter-spacing: 1px; text-transform: uppercase;">GOVERNO DO ESTADO DE SÃO PAULO</h4>
            <h3 style="margin: 3px 0; font-family: Cambria, Georgia, serif; font-size: 11pt; font-weight: bold; color: #1e293b; text-transform: uppercase;">SECRETARIA DA EDUCAÇÃO DO ESTADO DE SÃO PAULO - SEDUC-SP</h3>
            <h2 style="margin: 4px 0 2px 0; font-family: Cambria, Georgia, serif; font-size: 13pt; font-weight: bold; color: #1e3a8a; text-transform: uppercase;">PLANO DE RECUPERAÇÃO SEMESTRAL</h2>
            <span style="font-family: Cambria, Georgia, serif; font-size: 8.5pt; font-weight: bold; color: #475569; background-color: #f1f5f9; padding: 3px 12px; border-radius: 10px; border: 1px solid #e2e8f0; display: inline-block; margin-top: 3px;">1º Semestre Letivo / Alinhamento SEDUC – 2026</span>
          </td>
        </tr>
      </table>

      <!-- TABELA DE IDENTIFICAÇÃO -->
      <table border="1" width="100%" style="width: 100%; border-collapse: collapse; margin-bottom: 24px; border: 1.5px solid #1e3a8a; font-size: 11pt; font-family: Cambria, Georgia, serif; table-layout: fixed; mso-table-layout-alt: fixed; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
        <colgroup>
          <col width="25%" style="width: 25%;">
          <col width="25%" style="width: 25%;">
          <col width="25%" style="width: 25%;">
          <col width="25%" style="width: 25%;">
        </colgroup>
        <tr>
          <td width="25%" style="border: 1px solid #cbd5e1; padding: 8px 12px; font-weight: bold; font-size: 12pt; color: #1e3a8a; background-color: #f8fafc; width: 25%; word-wrap: break-word;">Unidade Escolar:</td>
          <td width="75%" style="border: 1px solid #cbd5e1; padding: 8px 12px; color: #334155; width: 75%; font-size: 11pt; font-weight: normal; word-wrap: break-word;" colspan="3">${escapeHtml(a)||"E.E. de Ensino Integral Estadual"}</td>
        </tr>
        <tr>
          <td width="25%" style="border: 1px solid #cbd5e1; padding: 8px 12px; font-weight: bold; font-size: 12pt; color: #1e3a8a; background-color: #f8fafc; width: 25%; word-wrap: break-word;">Docente Responsável:</td>
          <td width="75%" style="border: 1px solid #cbd5e1; padding: 8px 12px; color: #334155; font-size: 11pt; font-weight: normal; width: 75%; word-wrap: break-word;" colspan="3">${escapeHtml(e)||"Professor(a) de Apoio Escolar / Tutor"}</td>
        </tr>
        <tr>
          <td width="25%" style="border: 1px solid #cbd5e1; padding: 8px 12px; font-weight: bold; font-size: 12pt; color: #1e3a8a; background-color: #f8fafc; width: 25%; word-wrap: break-word;">Componente Curricular:</td>
          <td width="25%" style="border: 1px solid #cbd5e1; padding: 8px 12px; color: #334155; width: 25%; font-size: 11pt; font-weight: normal; word-wrap: break-word;">${escapeHtml(o.componente)}</td>
          <td width="25%" style="border: 1px solid #cbd5e1; padding: 8px 12px; font-weight: bold; font-size: 12pt; color: #1e3a8a; background-color: #f8fafc; width: 25%; word-wrap: break-word;">Série / Ano:</td>
          <td width="25%" style="border: 1px solid #cbd5e1; padding: 8px 12px; color: #334155; width: 25%; font-size: 11pt; font-weight: normal; word-wrap: break-word;">${escapeHtml(o.ano)}</td>
        </tr>
        <tr>
          <td width="25%" style="border: 1px solid #cbd5e1; padding: 8px 12px; font-weight: bold; font-size: 12pt; color: #1e3a8a; background-color: #f8fafc; width: 25%; word-wrap: break-word;">Período Alvo:</td>
          <td width="25%" style="border: 1px solid #cbd5e1; padding: 8px 12px; color: #334155; font-size: 11pt; font-weight: normal; width: 25%; word-wrap: break-word;">1º Semestre (1º e 2º Bimestres Integrados)</td>
          <td width="25%" style="border: 1px solid #cbd5e1; padding: 8px 12px; font-weight: bold; font-size: 12pt; color: #1e3a8a; background-color: #f8fafc; width: 25%; word-wrap: break-word;">Carga Horária:</td>
          <td width="25%" style="border: 1px solid #cbd5e1; padding: 8px 12px; color: #334155; font-size: 11pt; font-weight: normal; width: 25%; word-wrap: break-word;">${escapeHtml(o.aulas)} aulas de recomposição</td>
        </tr>
      </table>

      <!-- SEÇÃO 1: FUNDAMENTAÇÃO LEGAL -->
      <div style="margin-bottom: 24px;">
        <div style="border-left: 4px solid #1e3a8a; padding-left: 10px; margin-bottom: 10px;">
          <h4 style="margin: 0; font-family: Arial, Helvetica, sans-serif; font-size: 11pt; font-weight: 800; color: #1e3a8a; text-transform: uppercase; letter-spacing: 0.5px;">1. Diretrizes e Fundamentação</h4>
        </div>
        <p style="margin: 0; font-size: 10.5pt; text-align: justify; text-indent: 1.5cm; color: #334155; line-height: 1.6;">${i.ancoragemLegal}</p>
      </div>

      <!-- SEÇÃO 2: HABILIDADES E CONTEÚDOS DA RECUPERAÇÃO -->
      <div style="margin-bottom: 24px;">
        <div style="border-left: 4px solid #1e3a8a; padding-left: 10px; margin-bottom: 10px;">
          <h4 style="margin: 0; font-family: Arial, Helvetica, sans-serif; font-size: 11pt; font-weight: 800; color: #1e3a8a; text-transform: uppercase; letter-spacing: 0.5px;">2. Habilidades e Conteúdos Focais</h4>
        </div>
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 14px; font-size: 10pt; color: #334155;">
          <p style="margin: 4px 0; line-height: 1.5;"><strong>Nível Cognitivo / Ação Pedagógica:</strong> <span style="color: #1e3a8a; font-weight: 600;">${i.verboComando}</span></p>
          <div style="border-top: 1px solid #e2e8f0; margin: 8px 0; padding-top: 8px;"></div>
          <p style="margin: 4px 0; line-height: 1.5; white-space: pre-wrap;"><strong>Conteúdos Principais do Semestre:</strong> <span style="font-weight: 500; display: block; margin-top: 4px; padding-left: 8px; border-left: 2px solid #cbd5e1;">${i.objetoConhecimento}</span></p>
          <div style="border-top: 1px solid #e2e8f0; margin: 8px 0; padding-top: 8px;"></div>
          <p style="margin: 4px 0; line-height: 1.5;"><strong>Objetivo Prático:</strong> <span>${i.modificador}</span></p>
          <div style="border-top: 1px solid #e2e8f0; margin: 8px 0; padding-top: 8px;"></div>
          <p style="margin: 4px 0; line-height: 1.5; white-space: pre-wrap;"><strong>Habilidades do Currículo Paulista (2026):</strong> <span style="font-weight: 500; color: #1e3a8a; display: block; margin-top: 4px; padding-left: 8px; border-left: 2px solid #cbd5e1;">${i.habilidadesRelacionadas}</span></p>
          <div style="border-top: 1px solid #e2e8f0; margin: 8px 0; padding-top: 8px;"></div>
          <p style="margin: 4px 0; line-height: 1.5;"><strong>Conhecimentos Prévios de Suporte:</strong> <span>${i.habilidadesPrevias}</span></p>
        </div>
      </div>

      <!-- SEÇÃO 3: MATRIZ DE ALINHAMENTO COGNITIVO -->
      <div style="margin-bottom: 24px;">
        <div style="border-left: 4px solid #1e3a8a; padding-left: 10px; margin-bottom: 10px;">
          <h4 style="margin: 0; font-family: Arial, Helvetica, sans-serif; font-size: 11pt; font-weight: 800; color: #1e3a8a; text-transform: uppercase; letter-spacing: 0.5px;">3. Matriz de Níveis de Aprendizagem</h4>
        </div>
        ${s}
      </div>

      <!-- SEÇÃO 4: PLANO DE AULAS DE RECUPERAÇÃO -->
      <div style="margin-bottom: 24px;">
        <div style="border-left: 4px solid #1e3a8a; padding-left: 10px; margin-bottom: 10px;">
          <h4 style="margin: 0; font-family: Arial, Helvetica, sans-serif; font-size: 11pt; font-weight: 800; color: #1e3a8a; text-transform: uppercase; letter-spacing: 0.5px;">4. Cronograma de Aulas de Recuperação</h4>
        </div>
        <p style="margin: 0 0 10px 0; font-size: 9.5pt; font-style: italic; color: #64748b;">Aulas organizadas para o aprofundamento das habilidades defasadas, com apoio de duplas e tutoria pedagógica.</p>
        ${t}
      </div>

      <!-- SEÇÃO 5: ADAPTAÇÃO CURRICULAR E MATERIAIS DE APOIO -->
      <div style="margin-bottom: 24px;">
        <div style="border-left: 4px solid #1e3a8a; padding-left: 10px; margin-bottom: 10px;">
          <h4 style="margin: 0; font-family: Arial, Helvetica, sans-serif; font-size: 11pt; font-weight: 800; color: #1e3a8a; text-transform: uppercase; letter-spacing: 0.5px;">5. Adaptação Curricular e Estratégias Diferenciadas</h4>
        </div>
        <div style="background-color: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px; padding: 14px; font-size: 10pt; color: #334155;">
          <p style="margin: 0 0 8px 0; font-weight: 700; color: #1e3a8a; font-size: 10pt; text-transform: uppercase;">Estratégias de Adaptação Adotadas:</p>
          <ul style="margin: 0 0 12px 0; padding-left: 20px; font-size: 9.5pt; color: #334155;">
            ${d}
          </ul>

          <div style="border-top: 1px solid #e2e8f0; margin: 10px 0; padding-top: 10px;"></div>

          <p style="margin: 0 0 4px 0; font-weight: 700; color: #1e3a8a; font-size: 10pt; text-transform: uppercase;">Sugestão de Materiais para Adaptação de Atividades:</p>
          <p style="margin: 0 0 12px 0; font-size: 9.5pt; color: #334155; line-height: 1.5;">${c}</p>

          <div style="border-top: 1px solid #e2e8f0; margin: 10px 0; padding-top: 10px;"></div>

          <p style="margin: 0 0 4px 0; font-weight: 700; color: #1e3a8a; font-size: 10pt; text-transform: uppercase;">Previsão de Retomada de Aprendizagens Essenciais (Bimestres Anteriores):</p>
          <p style="margin: 0; font-size: 9.5pt; color: #334155; line-height: 1.5;">${m}</p>
        </div>
      </div>

      <!-- SEÇÃO 6: AVALIAÇÃO FORMATIVA -->
      <div style="margin-bottom: 24px; page-break-inside: avoid;">
        <div style="border-left: 4px solid #1e3a8a; padding-left: 10px; margin-bottom: 10px;">
          <h4 style="margin: 0; font-family: Arial, Helvetica, sans-serif; font-size: 11pt; font-weight: 800; color: #1e3a8a; text-transform: uppercase; letter-spacing: 0.5px;">6. Atividades e Avaliação Formativa</h4>
        </div>
        <div style="background-color: #f8fafc; border: 1.5px solid #cbd5e1; border-left: 4px solid #15803d; padding: 16px; border-radius: 6px; font-size: 10.5pt; font-family: Arial, Helvetica, sans-serif; margin-top: 10px;">
          <div style="margin-bottom: 15px;">
            <span style="background-color: #e2e8f0; color: #334155; font-size: 8pt; font-weight: 700; padding: 2px 8px; border-radius: 4px; display: inline-block; margin-bottom: 6px; text-transform: uppercase;">Exercícios de Verificação</span>
            <p style="margin: 5px 0; white-space: pre-wrap; line-height: 1.5; color: #1e293b; font-weight: 500;">${i.itemAvaliacao}</p>
          </div>
          
          <div style="border-top: 2.5px dashed #cbd5e1; margin: 16px 0; padding-top: 12px;"></div>
          
          <p style="margin: 5px 0 10px 0; font-weight: 700; color: #15803d; font-size: 11pt; background-color: #d1fae5; display: inline-block; padding: 4px 12px; border-radius: 4px; border: 1px solid #a7f3d0;">${i.gabarito}</p>
          
          <div style="margin-top: 14px;">
            <p style="margin: 0 0 6px 0; font-weight: 700; color: #1e293b; font-size: 10pt; text-transform: uppercase; letter-spacing: 0.3px;">Análise Pedagógica e Orientações:</p>
            <p style="margin: 0; font-size: 9.5pt; white-space: pre-wrap; text-align: justify; color: #475569; line-height: 1.5;">${i.feedbackPedagogico}</p>
          </div>
        </div>
      </div>
    </div>
  `}

export function generateRecoveryPlanMarkdown(a,e,i,o){const s=(o.adaptacaoCurricularOptions&&o.adaptacaoCurricularOptions.length>0?o.adaptacaoCurricularOptions:["Responder dúvidas recorrentes, retomando explicações","Oferecer exemplos adicionais ou utilizar outra estratégia de explicação para o mesmo conceito","Propor atividades de apoio para estudantes que ainda não consolidaram a aprendizagem","Disponibilizar desafios para estudantes que já dominaram o conteúdo"]).map(c=>`- ${c}`).join(`
`),t=o.sugestaoMateriais||"Jogos pedagógicos, fichas de exercícios impressas com apoio visual, esquemas gráficos e infográficos, objetos manipuláveis e tutoria entre pares.",d=o.retomadaAprendizagensAnteriores||"Revisão prática dos conceitos fundamentais do 1º e 2º bimestres anteriores necessários para a consolidação das habilidades essenciais em defasagem.";return`# PLANO DE RECUPERAÇÃO SEMESTRAL (2026)

**Unidade Escolar**: ${a||"E.E. de Ensino Integral Estadual"}  
**Docente Responsável**: ${e||"Professor(a) de Apoio Escolar / Tutor"}  
**Componente Curricular**: ${o.componente}  
**Série / Ano**: ${o.ano}  
**Período**: 1º Semestre (1º e 2º Bimestres Integrados)  
**Carga Horária**: ${o.aulas} aulas de recomposição  

---

## 1. Diretrizes e Fundamentação
${i.ancoragemLegal}

---

## 2. Habilidades e Conteúdos Focais
- **Nível Cognitivo / Ação Pedagógica**: ${i.verboComando}
- **Conteúdos Principais do Semestre**: ${i.objetoConhecimento}
- **Objetivo Prático**: ${i.modificador}
- **Habilidades do Currículo Paulista (2026)**: 
${i.habilidadesRelacionadas}
- **Conhecimentos Prévios de Suporte**: ${i.habilidadesPrevias}

---

## 3. Matriz de Níveis de Aprendizagem
${i.matrizCognitiva}

---

## 4. Cronograma de Aulas de Recuperação
${i.planoAulas}

---

## 5. Adaptação Curricular e Estratégias Diferenciadas
### Estratégias de Adaptação Adotadas:
${s}

### Sugestão de Materiais para Adaptação de Atividades:
${t}

### Previsão de Retomada de Aprendizagens Essenciais (Bimestres Anteriores):
${d}

---

## 6. Atividades e Avaliação Formativa
### Exercícios de Verificação:
${i.itemAvaliacao}

### Gabarito:
${i.gabarito}

### Análise Pedagógica e Orientações:
${i.feedbackPedagogico}
`}

