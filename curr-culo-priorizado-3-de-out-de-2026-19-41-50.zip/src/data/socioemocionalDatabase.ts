export interface SocioemocionalCell {
  contexto: string;
  questoes: string;
  habilidade: string;
  curriculoPaulista?: string;
  atitude?: string;
  pratica?: string;
  bigFive?: string;
  estrategias: string[];
}

export interface SocioemocionalBimestres {
  bimestres: Record<string, SocioemocionalCell>;
}

export interface SocioemocionalRow {
  dimension: string;
  macro?: string;
  descricao?: string;
  comprehensions: Record<string, string>;
  grades: Record<string, SocioemocionalBimestres>;
}

export const MATRIZ_SOCIOEMOCIONAL: SocioemocionalRow[] = [
  {
    dimension: "Amabilidade",
    macro: "Amabilidade",
    descricao: "Capacidade de agir com empatia, generosidade, consideração e respeito pelos outros.",
    comprehensions: {
      "6º Ano": "Desenvolvimento da empatia e colaboração interpessoal."
    },
    grades: {
      "6º Ano": {
        bimestres: {
          "1º Bimestre": {
            contexto: "Relações interpessoais e convivência escolar.",
            questoes: "Como agir com respeito e empatia?",
            habilidade: "Empatia e Respeito",
            curriculoPaulista: "EF06LP01",
            atitude: "Colaboração",
            pratica: "Diálogo respeitoso",
            bigFive: "Amabilidade",
            estrategias: ["Roda de conversa", "Dinâmicas de grupo"]
          }
        }
      }
    }
  },
  {
    dimension: "Autogestão",
    macro: "Autogestão",
    descricao: "Capacidade de gerenciar metas, manter a disciplina, planejar ações e persistir diante de desafios.",
    comprehensions: {
      "6º Ano": "Organização do tempo e foco nos estudos."
    },
    grades: {
      "6º Ano": {
        bimestres: {
          "1º Bimestre": {
            contexto: "Gestão do tempo e rotinas de estudo.",
            questoes: "Como planejar as metas de aprendizado?",
            habilidade: "Foco e Organização",
            curriculoPaulista: "EF06MA01",
            atitude: "Responsabilidade",
            pratica: "Planejamento pessoal",
            bigFive: "Autogestão",
            estrategias: ["Plano de estudo semanal", "Autoavaliação"]
          }
        }
      }
    }
  }
];
