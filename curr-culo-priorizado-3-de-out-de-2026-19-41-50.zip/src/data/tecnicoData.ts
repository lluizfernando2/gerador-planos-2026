import { CurriculumItem } from "../types";

export const ALL_TECNICO_DATA: CurriculumItem[] = [
  {
    id: "adm-1s-1b-1",
    ano: "1ª Série",
    bimestre: "1º Bimestre",
    aula: "1",
    titulo: "Introdução à Administração",
    conteudo: "Conceitos fundamentais de gestão e organizações.",
    objetivos: "Compreender o papel do administrador.",
    habilidade: "Identificar as funções administrativas essenciais.",
    disciplina: "Administração"
  },
  {
    id: "ds-1s-1b-1",
    ano: "1ª Série",
    bimestre: "1º Bimestre",
    aula: "1",
    titulo: "Lógica de Programação",
    conteudo: "Algoritmos, variáveis e estruturas de controle.",
    objetivos: "Desenvolver algoritmos estruturados.",
    habilidade: "Construir sequências lógicas de instruções.",
    disciplina: "Desenvolvimento de Sistemas"
  }
];

export function mapTecnicoToCurriculum(item: any): CurriculumItem {
  return {
    id: item.id || `tec-${Math.random()}`,
    ano: item.ano || "",
    bimestre: item.bimestre || "",
    aula: String(item.aula || ""),
    titulo: item.titulo || "",
    conteudo: item.conteudo || "",
    objetivos: item.objetivos || "",
    habilidade: item.habilidade || "",
    disciplina: item.disciplina || "Ensino Técnico"
  };
}
