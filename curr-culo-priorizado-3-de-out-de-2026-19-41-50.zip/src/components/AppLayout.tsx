import React, { useState } from 'react';
import { 
  Home, 
  BookOpen, 
  FileText, 
  GraduationCap, 
  Bookmark, 
  HelpCircle, 
  Settings, 
  Check, 
  AlertTriangle, 
  RotateCw, 
  Menu, 
  X, 
  Calendar,
  Grid,
  ChevronRight
} from 'lucide-react';
import ThemeToggle from './ThemeToggle';

export interface AppLayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: any) => void;
  favoritesCount: number;
  onShowTour: () => void;
  saveStatus?: 'saved' | 'saving' | 'error' | 'idle';
  currentPlanningTitle?: string;
}

export default function AppLayout({
  children,
  activeTab,
  setActiveTab,
  favoritesCount,
  onShowTour,
  saveStatus = 'saved',
}: AppLayoutProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Hub Principal', icon: Grid },
    { id: 'plan-generator', label: 'Plano de Ensino', icon: BookOpen },
    { id: 'recovery-plan', label: 'Recuperação', icon: GraduationCap },
    { id: 'curriculum', label: 'Matriz Curricular', icon: FileText },
    { id: 'assessment-calendar', label: 'Avaliações 4º Bim', icon: Calendar },
    { id: 'repositories', label: 'Questões', icon: HelpCircle },
    { id: 'favorites', label: 'Favoritos', icon: Bookmark, badge: favoritesCount > 0 ? favoritesCount : undefined },
    { id: 'settings', label: 'Configurações', icon: Settings },
  ];

  const handleNavClick = (id: string) => {
    if (id === 'help') {
      onShowTour();
      setActiveTab('help');
    } else {
      setActiveTab(id);
    }
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getBreadcrumbs = () => {
    switch (activeTab) {
      case 'dashboard':
      case 'home':
        return ['Início', 'Hub Principal de Ferramentas'];
      case 'plan-generator':
        return ['Planejamento de Ensino', 'Plano de Ensino (10 Semanas)'];
      case 'curriculum':
        return ['Consulta Curricular', 'Matriz Paulista 2026'];
      case 'assessment-calendar':
        return ['Calendário 2026', 'Avaliações Externas 4º Bimestre'];
      case 'recovery-plan':
        return ['Recuperação', 'Plano Semestral (Res. SEDUC 42/2024)'];
      case 'repositories':
        return ['Banco de Questões', 'Atividades Verificadoras'];
      case 'favorites':
        return ['Favoritos', 'Acervo Pessoal de Habilidades'];
      case 'settings':
        return ['Configurações', 'Preferências & Sistema'];
      case 'help':
        return ['Ajuda', 'Central de Treinamento'];
      default:
        return ['Início'];
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors duration-200 selection:bg-sky-100 selection:text-sky-900" translate="no" lang="pt-BR">
      
      {/* TOP INSTITUTIONAL HEADER NAVBAR */}
      <header className="bg-slate-900 text-slate-200 border-b border-slate-800 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* BRANDING LOGO & TITLE */}
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => handleNavClick('dashboard')}>
              <div className="w-9 h-9 rounded-xl bg-sky-600 flex items-center justify-center text-white font-bold shadow-xs">
                <BookOpen className="h-5 w-5" />
              </div>
              <div>
                <span className="text-sm font-extrabold text-white tracking-tight block">
                  Currículo Priorizado
                </span>
                <span className="text-[10px] text-sky-400 font-semibold uppercase tracking-wider block">
                  Sede SP • 2026
                </span>
              </div>
            </div>

            {/* DESKTOP TOP HORIZONTAL TOOLBAR */}
            <nav className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => {
                const IconComp = item.icon;
                const isActive = activeTab === item.id || (activeTab === 'home' && item.id === 'dashboard');
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                      isActive
                        ? 'bg-sky-600 text-white shadow-xs'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                    }`}
                  >
                    <IconComp className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                    {item.badge !== undefined && (
                      <span className="text-[10px] font-extrabold bg-sky-500/30 text-sky-200 px-1.5 py-0.2 rounded-full">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* HEADER RIGHT UTILITIES */}
            <div className="flex items-center gap-3">
              {/* AUTOSAVE INDICATOR WHEN IN PLANNER */}
              {activeTab === 'plan-generator' && (
                <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-slate-800 rounded-full border border-slate-700 text-xs font-medium">
                  {saveStatus === 'saving' && (
                    <>
                      <RotateCw className="w-3.5 h-3.5 text-sky-400 animate-spin" />
                      <span className="text-sky-300">Salvando...</span>
                    </>
                  )}
                  {saveStatus === 'saved' && (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-slate-300 text-[11px]">Salvo</span>
                    </>
                  )}
                  {saveStatus === 'error' && (
                    <>
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                      <span className="text-amber-300 text-[11px]">Falha</span>
                    </>
                  )}
                </div>
              )}

              <ThemeToggle />

              {/* MOBILE MENU TRIGGER */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="lg:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 cursor-pointer"
                aria-label="Abrir navegação"
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

          </div>
        </div>

        {/* MOBILE MENU DROPDOWN */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-800 bg-slate-900 px-4 py-3 space-y-1 animate-fadeIn">
            {navItems.map((item) => {
              const IconComp = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between p-2.5 rounded-lg text-xs font-bold text-left transition ${
                    isActive
                      ? 'bg-sky-600 text-white'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <IconComp className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className="text-[10px] bg-sky-500/30 text-sky-200 px-2 py-0.5 rounded-full">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </header>

      {/* SUB-HEADER BREADCRUMB BAR */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-2.5 shadow-2xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2 flex-wrap">
            {getBreadcrumbs().map((crumb, idx) => (
              <React.Fragment key={idx}>
                {idx > 0 && <ChevronRight className="w-3 h-3 text-slate-400" />}
                <span className={idx === getBreadcrumbs().length - 1 ? 'text-slate-900 dark:text-slate-100 font-bold' : ''}>
                  {crumb}
                </span>
              </React.Fragment>
            ))}
          </div>

          {activeTab !== 'dashboard' && activeTab !== 'home' && (
            <button
              onClick={() => handleNavClick('dashboard')}
              className="text-xs font-bold text-sky-600 dark:text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>← Voltar ao Hub Principal</span>
            </button>
          )}
        </div>
      </div>

      {/* SCROLLABLE MAIN CONTENT */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {children}
      </main>

    </div>
  );
}
